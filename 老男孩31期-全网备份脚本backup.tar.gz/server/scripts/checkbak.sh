#!/bin/sh
export LANG=en
find /backup/ -name "flag_$(date +%F)*"|xargs md5sum -c &>/tmp/mail_$(date +%F).log
if [ $(date +%w) -eq 2 ];then
 date="$(date +%F -d "-1day")_week1"
else
 date="$(date +%F -d "-1day")"
fi

find /backup/ -type f -name "*.tar.gz" -a ! -name "*week1*" -mtime +1|xargs rm -f
mail -s "backup `date`" 2934145242@qq.com </tmp/mail_$(date +%F).log
\cp /tmp/mail_$(date +%F).log /tmp/mail_$(date +%F).log.ori
>/tmp/mail_$(date +%F).log
