#!/bin/sh
if [ $# -ne 2 ];then
  echo "/bin/sh $0 hostname PartIP"
  exit 1
fi
sed  -i "s#oldboy#$1#g" /etc/sysconfig/network
hostname $1
sed -i "s#100#$2#g" /etc/sysconfig/network-scripts/ifcfg-eth0
sed -i "s#100#$2#g" /etc/sysconfig/network-scripts/ifcfg-eth1
/etc/init.d/network restart
